# Chapter 3 - Understanding OS-backed Event Queues, System Calls and Cross Platform Abstractions

This folder contains the code examples for Chapter 3.
