# Chapter 5 - Creating Our Own Fibers

This folder contains the code examples for Chapter 5.

## Note

For MacOS users running M-family chips (most newer Macs), there is a few
simple steps you can take to get the example running on your machine.

It's explained step-by-step in [How-to-MacOS-M.md](./How-to-MacOS-M.md).
