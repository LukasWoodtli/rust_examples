# Chapter 7 - Coroutines and async/await

This folder contains the code examples for Chapter 7.

## Note

This folder also contains `corofy` that you'll need to install locally since
you need it in this and the following chapters.

You'll find all the details on how to do this both in the book and in the [corofy](./corofy/) folder.